<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colorlib Templates">
    <meta name="author" content="Colorlib">
    <meta name="keywords" content="Colorlib Templates">

    <!-- Title Page-->
    <title>Au Register Forms by Colorlib</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>

    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">   
        <div class="wrapper wrapper--w680">
<?php

$servername = "localhost";
$username 	= "root";
$password 	= "";
$db 		= "reg_form";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

	if (isset($_POST['submit_btn'])) {
		$errors = 0;
		if (empty($_POST['first_name'])) {
			$fname_err = "First name required";
			$errors++;
		}
		if (empty($_POST['last_name'])) {
			$lastname_err = "Last name required";
			$errors++;
		}
		if (empty($_POST['birthday'])) {
			$bithday_err = "Birthday required";
			$errors++;
		}
		if (empty($_POST['gender'])) {
			$gender_err = "Gender required";
			$errors++;
		}        
		if (empty($_POST['email'])) {
			$email_err = "Email required";
			$errors++;
		}
		if (empty($_POST['phone_number'])) {
			$phonenumber_err = "Phone Number required";
			$errors++;
		}
		if (empty($_POST['subject'])) {
			$subject_err = "Subject required";
			$errors++;
		}
    $target_dir = "images/";
    $target_file = $target_dir . basename($_FILES["pic"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

    $image='images/'.basename( $_FILES["pic"]["name"]);                                                                
		if ($errors == 0) {
			$query = "INSERT INTO registration (first_name,last_name,birthday,gender,email,phone_number,subject,reg_pic) VALUES ('$_POST[first_name]','$_POST[last_name]','$_POST[birthday]','$_POST[gender]','$_POST[email]','$_POST[phone_number]','$_POST[subject]','$image')";
			if ($conn->query($query) == TRUE) {
				echo "<div class='sucmsg'>Form Submitted Successfully</div>";
			}
			else{
				echo "Error: " . $query . "<br>" . $conn->error;
				// echo $query->error;
			}

			
		}
	}
?>            
            <div class="card card-4">        
                <div class="card-body">
                    <h2 class="title">Registration Form</h2>
                    <form method="POST" enctype="multipart/form-data">
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">first name</label>
                                    <input class="input--style-4" type="text" name="first_name">
                                    <error>
                                    <?php 
                        			echo (isset($fname_err))? $fname_err : '';
                        			 ?>
                        			</error>                                    
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">last name</label>
                                    <input class="input--style-4" type="text" name="last_name">
                                    <error>
                                    <?php 
                        			echo (isset($lastname_err))? $lastname_err : '';
                        			 ?>
                        			</error>                                       
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Birthday</label>
                                    <div class="input-group-icon">
                                        <input class="input--style-4 js-datepicker" type="text" name="birthday">
                                        <i class="zmdi zmdi-calendar-note input-icon js-btn-calendar"></i>
                                    <error>
                                    <?php 
                        			echo (isset($bithday_err))? $bithday_err : '';
                        			 ?>
                        			</error>                                           
                                    </div>
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Gender</label>
                                    <div class="p-t-10">
                                        <label class="radio-container m-r-45">Male
                                            <input type="radio" checked="checked" name="gender" value="Male">
                                            <span class="checkmark"></span>
                                        </label>
                                        <label class="radio-container">Female
                                            <input type="radio" name="gender" value="Female">
                                            <span class="checkmark"></span>
                                        </label>
                                                                                                                                     
                                    <error>
                                    <?php 
                        			echo (isset($gender_err))? $gender_err : '';
                        			 ?>
                        			</error>                                           
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Email</label>
                                    <input class="input--style-4" type="email" name="email">
                                    <error>
                                    <?php 
                        			echo (isset($email_err))? $email_err : '';
                        			 ?>
                        			</error>                                       
                                </div>
                            </div>
                            <div class="col-2">
                                <div class="input-group">
                                    <label class="label">Phone Number</label>
                                    <input class="input--style-4" type="text" name="phone_number">
                                    <error>
                                    <?php 
                        			echo (isset($phonenumber_err))? $phonenumber_err : '';
                        			 ?>
                        			</error>                                       
                                </div>
                            </div>
                        </div>
                        <div class="input-group">
                            <label class="label">Subject</label>
                            <div class="rs-select2 js-select-simple select--no-search">
                                <select name="subject">
                                    <option disabled="disabled" selected="selected">Choose option</option>
                                    <option>Subject 1</option>
                                    <option>Subject 2</option>
                                    <option>Subject 3</option>
                                </select>
                                <div class="select-dropdown"></div>
                                    <error>
                                    <?php 
                        			echo (isset($subject_err))? $subject_err : '';
                        			 ?>
                        			</error>                                   
                            </div>
                        </div>
                        <div class="row row-space">
                                <div class="input-group"> 
                                    <label class="label">Upload Image</label>
                                    <input class="input--style-4" type="file" name="pic">       
<?php
    if (move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["pic"]["name"]). " has been uploaded.";
    } else {
        echo "<error>Sorry, there was an error uploading your file.</error>";
    }
?>                                                                                                    
                        </div>  
                        <div class="clear" style="clear: both;float: none;width: 100%;"></div>                  
                        <div class="p-t-15">
                            <button name="submit_btn" class="btn btn--radius-2 btn--blue" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->